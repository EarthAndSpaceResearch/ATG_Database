% height_file_text2mat_2017_0816.m
%
% Script converts manually-edited atg_height_sites.txt, and writes the
%   Matlab data file used in the open distribution database 
%   (atg_database.mat).
%
% User can specify sites to suppress coefficients.
%
% Laurie Padman, Earth & Space Research, padman@esr.org
%
% Last update:  August 16, 2017.
%
%========================================================================

%sites_to_suppress=[nn nn nn ...]; % Coefficients will be set to
%  NaN for open distribution.
sites_to_suppress=[]; % Nothing to suppress

fid=fopen('ATG_ocean_height_2014_0207.txt');

% Number of header lines
nhead=18; maxlen=120; rowspersite=10;
header(1:nhead,1:maxlen)=' ';
for i=1:nhead
    str=fgetl(fid);
    header(i,:)=padstr(str,maxlen);
end

% Constituent order in file
atg.constit=['Q1';'O1';'P1';'K1';'N2';'M2';'S2';'K2'];

% Find number of stations in file
ig=0;
while 1
    dum=fgetl(fid);
    ig=ig+1;
    if(dum==-1); ig=ig-1; break; end
end
nstat=round(ig/rowspersite);
disp(['Number of stations in file ... ' num2str(nstat)])
frewind(fid)
% Skip headers again
for i=1:nhead
    dum=fgetl(fid);
end

%Arrays we need
atg.lat=NaN*ones(nstat,1); atg.lon=atg.lat; atg.site_id=atg.lat; 
atg.RecordLength=atg.lat; atg.DeltaTime=atg.lat;
atg.amp=NaN*ones(nstat,8); atg.Gphase=atg.amp;
atg.SiteName(     1:nstat,1:50)=' ';
atg.MeasType(1:nstat,1:maxlen)=' ';
atg.Reference(      1:nstat,1:maxlen)=' ';
% Read through text file, one site block at a time
for i=1:nstat
    str                       = fgetl(fid);
    atg.site_id(i)            = str2num(str(1:3));
    str                       = fgetl(fid);
    atg.SiteName(i,1:50)      = padstr(str,50);
    str                       = fgetl(fid);         % source
    atg.Reference(i,1:maxlen) = padstr(str,maxlen);
    str                       = fgetl(fid);         % name repeated
    str                       = fgetl(fid);
    nums                      = str2num(str(1:20));
    atg.lat(i)                = nums(1);
    atg.lon(i)                = nums(2);
    str                       = fgetl(fid);
    nums                      = str2num(str(1:20));    
    atg.RecordLength(i)       = nums(1);
    atg.DeltaTime(i)          = nums(2);
    str                       = fgetl(fid);
    atg.MeasType(i,1:maxlen)  = padstr(str,maxlen);
    % Read amplitude and phase lines
    am_str=fgetl(fid); am=str2num(am_str); 
    ph_str=fgetl(fid); ph=str2num(ph_str); 
    atg.amp(i,:)=am; atg.Gphase(i,:)=ph;
    % Dump blank separator line
    blank=fgetl(fid); 
end 
fclose(fid);

% Put all longitudes onto (-180,+180) range
loc=find(atg.lon>180); atg.lon(loc)=atg.lon(loc)-360;

% Blank out coefficients for non-public sites
for i=sites_to_suppress
    atg.amp(i,:)    = NaN*ones(1,8);
    atg.Gphase(i,:) = NaN*ones(1,8);
end

% Formatted by structure per single site.

for i=1:nstat
    ATG(i).constit      = atg.constit;
    ATG(i).lat          = atg.lat(i);
    ATG(i).lon          = atg.lon(i);
    ATG(i).site_id      = i;
    ATG(i).RecordLength = atg.RecordLength(i);
    ATG(i).DeltaTime    = atg.DeltaTime(i);
    ATG(i).amp          = atg.amp(i,:);
    ATG(i).Gphase       = atg.Gphase(i,:);
    ATG(i).SiteName     = atg.SiteName(i,:);
    ATG(i).MeasType     = atg.MeasType(i,:);
    ATG(i).Reference    = atg.Reference(i,:);
end

ATG_VECTORS=atg;
save ATG_ocean_height_2017_0816.mat header ATG_VECTORS ATG
